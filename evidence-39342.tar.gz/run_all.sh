#!/usr/bin/env bash
# Remaining validation queue after the eager arm-A probes on both builds.
set -uo pipefail
WS=/workspace/39342
cd "$WS"
run() { echo "=== $(date -u +%FT%TZ) START $*" | tee -a results/run_all.log; bash "$@" > "results/$(echo "$*" | tr ' /' '__').out" 2>&1; echo "=== $(date -u +%FT%TZ) END $* rc=$?" | tee -a results/run_all.log; }
run run_probe.sh base A graph
run run_probe.sh fix A graph
for b in base fix; do for arm in A B C; do run run_harness.sh $b $arm graph 200 3 32; done; done
run run_probe.sh fix B eager
run run_probe.sh fix C eager
run run_probe.sh base B eager
echo "ALL DONE $(date -u +%FT%TZ)" | tee -a results/run_all.log
